'use strict';
require('../register')('promise', {Promise: require('promise')})
