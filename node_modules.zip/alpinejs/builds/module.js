import Alpine from './../src/index'

export default Alpine
